<?php
$host="localhost";
$user="root";
$password="";
$databasename="contohfoto";

$con=  mysqli_connect($host,$user,$password,$databasename);

?>
