    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/jquery-1.11.2.min.js"></script>    
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/materialize.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- data-tables -->
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/plugins/data-tables/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/plugins/data-tables/data-tables-script.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/operator/js/plugins.js"></script>
    
    <script type="text/javascript">
      $('#alert_close').click(function(){
        $( "#alert_box" ).fadeOut( "slow", function() {
        });
      });
    </script>
</body>

</html>