<!DOCTYPE html>
<html>
	<?php $this->load->view('operator/header.php');?>
    <?php $this->load->view($isi);?>
    <?php $this->load->view('operator/footer.php');?>
</html>