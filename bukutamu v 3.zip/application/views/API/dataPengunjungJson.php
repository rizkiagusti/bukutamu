<?php
 

     // Header File XML
     header('Content-Type: application/json');

     echo json_encode($apiJson);
 
?>